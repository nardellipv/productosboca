<?php

namespace bocaamerica\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;
use Andreani\Andreani;
use Andreani\Requests\CotizarEnvio;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use bocaamerica\Cart;
use bocaamerica\Checkout;
use bocaamerica\Http\Requests\ContactInformationCartRequest;
use bocaamerica\Http\Requests\ProductRequest;
use bocaamerica\Product;
use MP;


class BuyController extends Controller
{
    public function addProduct($id, ProductRequest $request)
    {
        $product = Product::find($id);

        if (!Cookie::get('compra')) {
            $serial_buy = Str::random(10);
        } else {
            $serial_buy = Cookie::get('compra');
        }

        $addProduct = new Cart();
        $addProduct->serial_buy = $serial_buy;
        $addProduct->quantity = $request->quantity;
        $addProduct->size = $request['size'];
        if ($product->offer) {
            $addProduct->total = $request->quantity * $product->offer;
        } else {
            $addProduct->total = $request->quantity * $product->price;
        }
        $addProduct->product_id = $product->id;
        $addProduct->save();


        //        agrego el id del usuario a carts
        if(Auth::check()){
            $idUser = Cart::where('serial_buy', $serial_buy)
                ->get();

            foreach ($idUser as $key=>$value){
                $value->user_id = Auth::user()->id;
                $value->save();
            }
        }

        Cookie::queue('compra', $serial_buy, '2628000');

        Session::flash('message', 'El producto ' . $product->name . ' se agrego correctamente al carrito.');
        return back();
    }

    public function listProducts()
    {
        $subTotal = 0;
        $serial_buy = Cookie::get('compra');

        $compra = Cookie::get('compra');

        $productCarts = Cart::with(['product'])
            ->where('serial_buy', $compra)
            ->get();

        return view('parts.cart._cart', compact('productCarts', 'subTotal','serial_buy'));
    }

    public function checkout(ContactInformationCartRequest $request)
    {
        $serial_buy = Cookie::get('compra');
        // El precio para que no pague
        // envio se guarda en un txt
        $costoEnvio = File::get(storage_path('app/public/envio.txt'));

        $checkout = new Checkout();
        $checkout->serial_buy = $serial_buy;
        $checkout->fill($request->all())->save();


        //        agrego el id del usuario a carts
        if(Auth::check()){
            $idUser = Cart::where('serial_buy', $serial_buy)
                ->get();

            foreach ($idUser as $key=>$value){
                $value->status = 'CHECKOUT';
                $value->save();
            }
        }

        //calculo en el costo de envio
        /*$envio = $request->postalcode;

        //habilitar la extension soap en php.ini
        $requestAndreani = new CotizarEnvio();
        $requestAndreani->setCodigoDeCliente('CL0003750');
        $requestAndreani->setNumeroDeContrato('400006709');
        $requestAndreani->setCodigoPostal($envio);
        $requestAndreani->setPeso(2000);
        $requestAndreani->setVolumen(100);
        $requestAndreani->setValorDeclarado(100);

        $andreani = new Andreani('STAGING_WS', 'ANDREANI', 'prod');
        $response = $andreani->call($requestAndreani);

        if ($response->isValid()) {
            $tarifa = $response->getMessage()->CotizarEnvioResult->Tarifa;
        } else {
            $tarifa = 0;
        }
        //----------------------------

//        precio con envio
        if ($request->price < $costoEnvio) {
            $total = $request->price + $tarifa;

        } else {
            $total = $request->price;

        }*/

        //elimino cookie
//        Cookie::queue(Cookie::forget('compra'));

        //al percio le sumo el envio
        $total = $request->price + 350;

        if ($request->payment == 'mercadopago') {
            $mp = new MP('7545787281630019', 'eHRm9o2QMM9DT8m1FYmAlFgs6itcLPXV');

            $preference_data = [
                "items" => [
                    [
                        "id" => $checkout->product_id,
                        "title" => $request->productName,
                        "quantity" => 1,
                        "currency_id" => 'ARS',
                        "unit_price" => floatval($total),
                    ]
                ],
                "payer" => [
                    "name" => $request->name,
                    "surname" => $request->lastname,
                    "email" => $request->email,
                    "phone" => array(
                        "area_code" => "",
                        "number" => $request->phone,
                    ),
                ],
                "back_urls" => [
                    "success" => "www.bocaamerica.com/exito",
                    "pending" => "www.bocaamerica.com/pendiente",
                    "failure" => "www.bocaamerica.com/error",
                ]
            ];
            $preference = $mp->create_preference($preference_data);

            Mail::send('email._compra', $request->all(), function ($msj)  use ($request) {
                $msj->from('no-respond@bocaamerica.com');
                $msj->subject('Compra en Boca América');
                $msj->to($request->email, $request->name);
            });


            return Redirect::to($preference['response']['init_point']);
        }

        if ($request->payment == 'payu') {
            $apikey = "5nuNd7nPu7q20W2tN31CUImU42";
            $merchantId = "580345";

            $refernceCode = time();
            $amount = $total;
            $currency = "ARS";
            $stringToHash = $apikey . "~" . $merchantId . "~" . $refernceCode . "~" . $amount . "~" . $currency;
            $signature = md5($stringToHash);

            Mail::send('email._compra', $request->all(), function ($msj)  use ($request) {
                $msj->from('no-respond@bocaamerica.com');
                $msj->subject('Compra en Boca América');
                $msj->to($request->email, $request->name);
            });

            return view('parts.cart._payu', compact('apikey', 'merchantId', 'refernceCode', 'amount',
                'currency', 'signature', 'checkout'));
        }

        return back();
    }

    public function deleteItem($id)
    {
        $delProduct = Cart::find($id);

        $delProduct->delete();

        return back();
    }
}
