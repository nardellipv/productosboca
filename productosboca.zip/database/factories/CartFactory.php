<?php

use Faker\Generator as Faker;

$factory->define(bocaamerica\Cart::class, function (Faker $faker) {
    return [
        'serial_buy'=>$faker->md5,
        'quantity'=>$faker->numberBetween('1','5'),
        'total'=>$faker->numberBetween('1000','9999'),
        'status'=>$faker->randomElement(['CART','CHECKOUT']),
        'size' => $faker->randomElement(['S','M','XL','2XL']),
        'product_id' => rand(1, 100),
        'user_id' => rand(1, 10),
    ];
});
