<?php

use Faker\Generator as Faker;

$factory->define(bocaamerica\Discount::class, function (Faker $faker) {
    return [
        'coupon' => $faker->text(5),
        'discount' => rand(10,50),
        'status' => $faker->randomElement(['ACTIVE','DESACTIVE']),
    ];
});
