<?php

use Faker\Generator as Faker;

$factory->define(\bocaamerica\ProductSize::class, function (Faker $faker) {
    return [
        'size_id' => rand(1, 4),
        'product_id' => rand(1, 100),
    ];
});
