<?php

use Faker\Generator as Faker;

$factory->define(bocaamerica\Review::class, function (Faker $faker) {
    return [
        'review' => $faker->paragraph(3),
        'user_id' => rand('1','10'),
        'product_id' => rand('1','100'),
    ];
});
