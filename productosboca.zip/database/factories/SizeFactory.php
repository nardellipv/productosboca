<?php

use Faker\Generator as Faker;

$factory->define(bocaamerica\Size::class, function (Faker $faker) {
    return [
        'size' => $faker->randomElement(['S','M','XL','2XL']),
        'available' => $faker->randomElement(['YES', 'NO'])
    ];
});
