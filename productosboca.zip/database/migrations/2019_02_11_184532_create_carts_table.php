<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCartsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('carts', function (Blueprint $table) {
            $table->increments('id');

            $table->string('serial_buy');
            $table->integer('quantity');
            $table->integer('total');
            $table->enum('status',['CART', 'CHECKOUT'])->default('CART');
            $table->string('size');

            $table->integer('product_id')->unsigned();
            $table->integer('user_id')->unsigned()->nullable();

            $table->timestamps();

            // Relaciones

            $table->foreign('product_id')->references('id')->on('products');
            $table->foreign('user_id')->references('id')->on('users');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('carts');
    }
}
