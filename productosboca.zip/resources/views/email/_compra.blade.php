<!DOCTYPE html>
<html>
<head>
    <title>Boca América</title>
</head>
<body>
<p style="text-align: center;"><img alt="" src="imagen"></p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: left;">Hola {{ $name }},</p>
<p style="text-align: left;">&nbsp;</p>
<p style="text-align: left;">Muchas gracias por comprar en Boca América, dentro de poco te llegará un mail con el código de envío de tu paquete.</p>
<p style="text-align: left;">&nbsp;</p>
<p style="text-align: left;">Por cualquier consulta NO responda este email, contactarnos a través del sitio <a href="http://www.bocaamerica.com">www.bocaamerica.com</a>&nbsp;
o por email a info@bocaamerica.com</p>
<p style="text-align: left;">T&uacute; n&uacute;mero de orden es: <strong>{{ $serial_buy }}</strong></p>
<p style="text-align: left;">&nbsp;</p>
<p style="text-align: left;">NOTA: Recuerde guardar el comprobante de pago por cualquier inconveniente.</p>
<p style="text-align: left;">&nbsp;</p>
<p style="text-align: left;">Nuevamente muchas gracias por elegir BocaAmérica</p>
</body>
</html>