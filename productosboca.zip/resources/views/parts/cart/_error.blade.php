@extends('layouts.app')

@section('content')
    <div class="content">
        <div class="products-agileinfo">
            <h2 class="tittle">Compra realizada con éxito</h2>
            <div class="container">
                <br><br>
                <p class="text-center">La compra se realizó con algún error, por favor te pedimos que te comuniques con
                    algún representante de Boca América al mail info@bocaamerica.com y se pondran en contacto a la brevedad</p>
            </div>
        </div>
    </div>
@endsection