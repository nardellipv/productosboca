@extends('layouts.app')

@section('content')
    <div class="content">
        <div class="products-agileinfo">
            <h2 class="tittle">Compra realizada con éxito</h2>
            <div class="container">
                <br><br>
                <p class="text-center">La compra se realizó con éxito, se le enviará un email con los datos del envio.
                    Muchas gracias por su compra.</p>
            </div>
        </div>
    </div>
@endsection