@extends('layouts.app')

@section('content')
    <div class="content">
        <div class="products-agileinfo">
            <h2 class="tittle">Muchas gracias por registrarte</h2>
            <div class="container">
                <br><br>
                <p class="text-center">Ahora estaras acutalizado en cuando a las novedades que tenga el sitio y nuevos productos.</p>
            </div>
        </div>
    </div>
@endsection