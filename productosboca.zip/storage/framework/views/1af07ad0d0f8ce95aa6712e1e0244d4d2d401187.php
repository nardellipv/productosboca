<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('styleAdmin/plugins/datatables/dataTables.bootstrap.css')); ?>">
<?php $__env->stopSection(); ?>

    <div class="box">
        <div class="box-header">
            <h3 class="box-title">Listado de productos</h3>
        </div>
        <div class="box-body">
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Precio</th>
                    <th>Oferta</th>
                    <th>Sección</th>
                    <th>Categoría</th>
                    <th>Ranting</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->id); ?></td>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->description); ?></td>
                    <td>$<?php echo e($product->price); ?></td>
                    <td>$<?php echo e($product->offer); ?></td>
                    <td><?php echo e($product->section); ?></td>
                    <td><?php echo e($product->category->name); ?></td>
                    <td><?php echo e($product->rating); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('styleAdmin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('styleAdmin/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
        $(function () {
            $("#example1").DataTable();
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false
            });
        });
    </script>
<?php $__env->stopSection(); ?>