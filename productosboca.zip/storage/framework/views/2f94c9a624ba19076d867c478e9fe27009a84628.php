<?php $__env->startSection('content'); ?>
    <div class="content">
        <!--login-->
        <div class="login">
            <div class="main-agileits">
                <div class="form-w3agile">
                    <h3>Ingresar a Boca América</h3>
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="key">
                            <i class="fa fa-envelope" aria-hidden="true"></i>
                            <input type="text" value="<?php echo e(old('email')); ?>" placeholder="EMail" name="email"
                                   class="<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" required="">
                            <?php if($errors->has('email')): ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                            <?php endif; ?>
                            <div class="clearfix"></div>
                        </div>
                        <div class="key">
                            <i class="fa fa-lock" aria-hidden="true"></i>
                            <input type="password" placeholder="password" name="password"
                                   class="<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" required="">
                            <?php if($errors->has('password')): ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                            <?php endif; ?>
                            <div class="clearfix"></div>
                        </div>
                        <input type="submit" value="<?php echo e(__('Login')); ?>">
                    </form>
                </div>
                <div class="forg">
                    <?php if(Route::has('password.request')): ?>
                        <a href="<?php echo e(route('password.request')); ?>">
                            <?php echo e(__('Olvide mi password')); ?>

                        </a>
                    <?php endif; ?>
                    <a href="<?php echo e(url('register')); ?>" class="forg-right">Registrarme</a>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>