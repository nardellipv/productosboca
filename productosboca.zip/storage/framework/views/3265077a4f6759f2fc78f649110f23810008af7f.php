<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="mail-w3ls">
            <div class="container">
                <?php echo $__env->make('layouts.alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('layouts.alerts.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <h2 class="tittle">Contacto</h2>
                <div class="mail-grids">
                    <div class="mail-bottom">
                        <h4>Contactenos por cualquier consulta</h4>
                        <?php echo Form::open(['method' => 'POST','route' => ['sendEmail']]); ?>

                        <?php echo e(csrf_field()); ?>

                            <input type="text" name="name" id="name" placeholder="Nombre" value="<?php echo e(old('name')); ?>" required>
                            <input type="email" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required>
                            <input type="text" name="phone" placeholder="Teléfono" value="<?php echo e(old('phone')); ?>" required>
                            <textarea name="mensaje" placeholder="Mensaje..." required><?php echo e(old('mensaje')); ?></textarea>
                        <?php echo Recaptcha::render(); ?>

                            <input type="submit" value="Enviar">
                            <input type="reset" value="Borrar">
                        <?php echo Form::Close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>