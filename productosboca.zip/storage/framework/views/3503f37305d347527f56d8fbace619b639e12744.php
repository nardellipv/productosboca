<div class="header-top">
    <div class="container">
        <div class="top-left">
            <h5>Compras superiores a <b>$<?php echo e($costoEnvio); ?></b> envio <b>sin cargo</b></h5>
        </div>
        <div class="top-right">
            <ul>
                <?php if(Auth::check()): ?>
                    <li>Bienvenido <?php echo e(Auth::user()->name); ?></li>
                <?php endif; ?>
                <li><a href="<?php echo e(url('carrito')); ?>">Checkout</a></li>
                <?php if(Auth::check()): ?>
                    <li><a href="<?php echo e(url('perfil')); ?>">Perfíl</a></li>
                    <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
               document.getElementById('logout-form').submit();"> Salir </a></li>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                <?php else: ?>
                    <li><a href="<?php echo e(url('login')); ?>">Ingresar</a></li>
                    <li><a href="<?php echo e(url('register')); ?>"> Crear Cuenta </a></li>
                <?php endif; ?>
            </ul>
        </div>
        <div class="clearfix"></div>
    </div>
</div>