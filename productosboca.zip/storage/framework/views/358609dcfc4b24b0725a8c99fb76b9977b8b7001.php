<script language="javascript">
    function enviarForm()
    {
        document.form.submit();
    }
</script>
<body onLoad="javascript:enviarForm();">
<form method="post" name="form" action="https://gateway.payulatam.com/ppp-web-gateway/">
    <input name="merchantId" type="hidden" value="<?php echo e($merchantId); ?>">
    <input name="accountId" type="hidden" value="583246">
    <input name="description" type="hidden" value="compra producto Boca Amércia">
    <input name="referenceCode" type="hidden" value="<?php echo e($refernceCode); ?>">
    <input name="amount" type="hidden" value="<?php echo e($amount); ?>">
    <input name="tax" type="hidden" value="0">
    <input name="taxReturnBase" type="hidden" value="0">
    <input name="currency" type="hidden" value="<?php echo e($currency); ?>">
    <input name="signature" type="hidden" value="<?php echo e($signature); ?>">
    <input name="test" type="hidden" value="1">
    <input name="buyerEmail" type="hidden" value=<?php echo e($checkout->email); ?>>
    <input name="payerFullName" type="hidden" value=<?php echo e($checkout->name); ?> <?php echo e($checkout->lastname); ?>>
    <input name="responseUrl" type="hidden" value="www.bocaamerica.com/thanks">
    <input name="confirmationUrl" type="hidden" value="www.bocaamerica.com/thanks">
</form>
</body>