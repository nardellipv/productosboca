<div class="new-arrivals-w3agile">
    <div class="container">
        <h2 class="tittle">Nuevos Productos</h2>
        <div class="arrivals-grids">
            <?php $__currentLoopData = $newProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 arrival-grid simpleCart_shelfItem">
                    <div class="grid-arr">
                        <div class="grid-arrival">
                            <figure>
                                <a href="<?php echo e(url('producto', $newProduct->slug)); ?>" class="new-gri">
                                    <div class="grid-img">
                                        <img src="<?php echo e(asset('images/products/'.$newProduct->photo)); ?>"
                                             class="img-responsive" alt="<?php echo e($newProduct->name); ?>">
                                    </div>
                                    <div class="grid-img">
                                        <img src="<?php echo e(asset('images/products/'.$newProduct->photo)); ?>"
                                             class="img-responsive" alt="<?php echo e($newProduct->name); ?>">
                                    </div>
                                </a>
                            </figure>
                        </div>
                        <?php if($newProduct->quantity == 0): ?>
                            <div class="ribben1">
                                <p>Sin Stock</p>
                            </div>
                        <?php endif; ?>
                        <div class="women">
                            <h6><a href="<?php echo e(url('producto', $newProduct->slug)); ?>"><?php echo e(str_limit($newProduct->name, 50)); ?></a></h6>
                            <div class="block star-rating" style="margin-left: 38%;">
                                <div class="back-stars small ghosting">
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>

                                    <div class="front-stars" style="width: <?php echo e($newProduct->rating); ?>%">
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                    </div>
                                </div>
                            </div>
                            <span class="size">Precio: </span>
                            <?php if($newProduct->offer): ?>
                                <h5>
                                    <del>$<?php echo e($newProduct->price); ?></del>
                                </h5>
                                <h4 class="item_price">$<?php echo e($newProduct->offer); ?></h4>
                            <?php else: ?>
                                <p><em class="item_price">$<?php echo e($newProduct->price); ?></em></p>
                            <?php endif; ?>
                            <br>
                            <a href="<?php echo e(url('producto', $newProduct->slug)); ?>" class="my-cart-b item_add">Ver
                                Más</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="clearfix"></div>
        </div>
    </div>
</div>