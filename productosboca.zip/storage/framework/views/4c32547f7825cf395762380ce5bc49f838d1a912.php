<?php $__env->startSection('title', $category->name); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="products-agileinfo">
            <h2 class="tittle"><?php echo e($category->name); ?></h2>
            <div class="container">
                <div class="product-agileinfo-grids w3l">
                    <?php echo $__env->make('parts.product._aside', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="col-md-9 product-agileinfon-grid1 w3l">
                        <div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
                            <br><br>
                            <ul id="myTab" class="nav1 nav1-tabs left-tab" role="tablist">
                                <div id="myTabContent" class="tab-content">
                                    <div role="tabpanel" class="tab-pane fade in active" id="home"
                                         aria-labelledby="home-tab">
                                        <div class="product-tab">
                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-md-4 product-tab-grid simpleCart_shelfItem">
                                                    <div class="grid-arr">
                                                        <div class="grid-arrival">
                                                            <figure>
                                                                <a href="#" class="new-gri" data-toggle="modal"
                                                                   data-target="#myModal1">
                                                                    <div class="grid-img">
                                                                        <img src="<?php echo e(asset('images/products/'.$product->photo)); ?>"
                                                                             class="img-responsive"
                                                                             alt="<?php echo e($product->name); ?>">
                                                                    </div>
                                                                    <div class="grid-img">
                                                                        <img src="<?php echo e(asset('images/products/'.$product->photo)); ?>" class="img-responsive"
                                                                             alt="<?php echo e($product->name); ?>">
                                                                    </div>
                                                                </a>
                                                            </figure>
                                                        </div>
                                                        <?php if($product->quantity == 0): ?>
                                                            <div class="ribben1">
                                                                <p>Sin Stock</p>
                                                            </div>
                                                        <?php endif; ?>
                                                        <div class="women">
                                                            <h6><a href="<?php echo e(url('producto', $product->slug)); ?>"><?php echo e(str_limit($product->name,20)); ?></a></h6>
                                                            <div class="block star-rating" style="margin-left: 38%;">
                                                                <div class="back-stars small ghosting">
                                                                    <i class="fa fa-star" aria-hidden="true"></i>
                                                                    <i class="fa fa-star" aria-hidden="true"></i>
                                                                    <i class="fa fa-star" aria-hidden="true"></i>
                                                                    <i class="fa fa-star" aria-hidden="true"></i>
                                                                    <i class="fa fa-star" aria-hidden="true"></i>

                                                                    <div class="front-stars" style="width: <?php echo e($product->rating); ?>%">
                                                                        <i class="fa fa-star" aria-hidden="true"></i>
                                                                        <i class="fa fa-star" aria-hidden="true"></i>
                                                                        <i class="fa fa-star" aria-hidden="true"></i>
                                                                        <i class="fa fa-star" aria-hidden="true"></i>
                                                                        <i class="fa fa-star" aria-hidden="true"></i>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <span class="size">Precio:</span>
                                                            <?php if($product->offer): ?>
                                                                <h5>
                                                                    <del>$<?php echo e($product->price); ?></del>
                                                                </h5>
                                                                <h4 class="item_price">$<?php echo e($product->offer); ?></h4>
                                                            <?php else: ?>
                                                                <p><em class="item_price">$<?php echo e($product->price); ?></em></p>
                                                            <?php endif; ?>
                                                            <br>
                                                            <a href="<?php echo e(url('producto', $product->slug)); ?>" class="my-cart-b item_add">Ver Más</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <div class="clearfix"></div>
                                        </div>
                                    </div>
                                </div>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>