<div class="modal fade" id="compra-<?php echo e($buy->id); ?>" tabindex="-1" role="dialog" aria-labelledby="compraLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="compraLabel">Detalle de la compra</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <b>Nombre: </b> <?php echo e($buy->name); ?> <?php echo e($buy->lastname); ?> <br>
                <b>Email: </b> <?php echo e($buy->email); ?> <br>
                <b>Dirección: </b> <?php echo e($buy->address); ?> <br>
                <b>Provincia: </b> <?php echo e($buy->state); ?> <br>
                <b>Localidad: </b> <?php echo e($buy->dity); ?> <br>
                <b>CP: </b> <?php echo e($buy->postalcode); ?> <br>
                <b>Teléfono: </b> <?php echo e($buy->phone); ?> <br>
                <b>Nota: </b> <?php echo e($buy->note); ?> <br>
                <b>Pago: </b> <?php echo e($buy->payment); ?> <br>
                <b>Número compra: </b> <?php echo e($buy->serial_buy); ?> <br>
                <b>Cantidad: </b> <?php echo e($buy->cQuantity); ?> <br>
                <b>Total: </b> $<?php echo e($buy->total); ?> <br>
                <b>Producto Nombre: </b> <?php echo e($buy->productName); ?> <br>
                <b>Size: </b> <?php echo e($buy->caSize); ?> <br>
                <b>Producto Id: </b> <?php echo e($buy->productId); ?> <br>
                <b>Fecha Compra: </b> <?php echo e(Date::parse($buy->created_at)->format('j/m/Y H:m')); ?>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>