<div class="heder-bottom">
    <div class="container">
        <div class="logo-nav">
            <div class="logo-nav-left">
                <h1><a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('styleWeb/img/logochico.png')); ?>" alt="logo"/>BocaAmérica</a>
                </h1>
            </div>
            <div class="logo-nav-left1">
                <nav class="navbar navbar-default">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header nav_2">
                        <button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse"
                                data-target="#bs-megadropdown-tabs">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>
                    <div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
                        <ul class="nav navbar-nav">
                            <li><a href="<?php echo e(url('/')); ?>" class="act">Inicio</a></li>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(url('categoria', $category->slug)); ?>"><?php echo e($category->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(url('/mail/contacto')); ?>">Contacto</a></li>
                        </ul>
                    </div>
                </nav>
            </div>
            
            <div class="header-right2">
                <div class="cart box_1">
                    <a href="<?php echo e(route('listProducts')); ?>">
                        <h3>
                            <div class="total">
                                <?php if($countCart == 0): ?>
                                    <span>$ 0 </span> -
                                <?php else: ?>
                                    <span>$ <?php echo e($totalCart); ?> </span> -
                                <?php endif; ?>
                            </div>
                            <img src="<?php echo e(asset('styleWeb/img/icons/bag.png')); ?>" alt="carrito"/>
                            <span class="badge badge-warning"><?php echo e($countCart); ?></span>
                        </h3>
                    </a>
                    <div class="clearfix"></div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>