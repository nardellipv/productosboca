<?php $__env->startSection('title', $product->name); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('styleWeb/js/simpleCart.min.js')); ?>"></script>
    <script defer src="<?php echo e(asset('styleWeb/js/jquery.flexslider.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('styleWeb/css/flexslider.css')); ?>" media="screen"/>
    <script src="<?php echo e(asset('styleWeb/js/imagezoom.js')); ?>"></script>

    <script>
        const second = 1000,
            minute = second * 60,
            hour = minute * 60,
            day = hour * 24;

        let countDown = new Date("<?php echo e(Date::parse($product->time_offer)->format('F j, Y')); ?>").getTime(),
            x = setInterval(function () {

                let now = new Date().getTime(),
                    distance = countDown - now;

                document.getElementById('days').innerText = Math.floor(distance / (day)),
                    document.getElementById('hours').innerText = Math.floor((distance % (day)) / (hour)),
                    document.getElementById('minutes').innerText = Math.floor((distance % (hour)) / (minute)),
                    document.getElementById('seconds').innerText = Math.floor((distance % (minute)) / second);

                //do something later when date is reached
                //if (distance < 0) {
                //  clearInterval(x);
                //  'IT'S MY BIRTHDAY!;
                //}

            }, second)
    </script>
    <script>
        // Can also be used with $(document).ready()
        $(window).load(function () {
            $('.flexslider').flexslider({
                animation: "slide",
                controlNav: "thumbnails"
            });
        });
    </script>

    <style>
        .btn span.glyphicon {
            opacity: 0;
        }

        .btn.active span.glyphicon {
            opacity: 1;
        }

        .acidjs-rating-stars,
        .acidjs-rating-stars label::before {
            display: inline-block;
        }

        .acidjs-rating-stars label:hover,
        .acidjs-rating-stars label:hover ~ label {
            color: #189800;
        }

        .acidjs-rating-stars * {
            margin: 0;
            padding: 0;
        }

        .acidjs-rating-stars input {
            display: none;
        }

        .acidjs-rating-stars {
            unicode-bidi: bidi-override;
            direction: rtl;
        }

        .acidjs-rating-stars label {
            color: #ccc;
        }

        .acidjs-rating-stars label::before {
            content: "\2605";
            width: 18px;
            line-height: 18px;
            text-align: center;
            font-size: 18px;
            cursor: pointer;
        }

        .acidjs-rating-stars input:checked ~ label {
            color: #f5b301;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="cart-items">
            <div class="container">
                <div class="single-grids">
                    <div class="col-md-9 single-grid">
                        <?php echo $__env->make('layouts.alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php echo $__env->make('layouts.alerts.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <div class="single-top">
                            <div class="single-left">
                                <div class="flexslider">
                                    <ul class="slides">
                                        <?php $__currentLoopData = $pictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li data-thumb="<?php echo e(asset('images/products/'.$picture->url)); ?>">
                                                <div class="thumb-image"><img
                                                            src="<?php echo e(asset('images/products/'.$picture->url)); ?>"
                                                            data-imagezoom="true"
                                                            class="img-responsive">
                                                </div>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                            <div class="single-right simpleCart_shelfItem">
                                <h4><?php echo e($product->name); ?></h4>
                                <div class="block star-rating">
                                    <div class="back-stars small ghosting">
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>

                                        <div class="front-stars" style="width: <?php echo e($product->rating); ?>%">
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                                <br>

                                <?php if($product->offer): ?>
                                    <h3>
                                        <del>$<?php echo e($product->price); ?></del>
                                    </h3>
                                    <p class="price item_price">$<?php echo e($product->offer); ?></p>
                                <?php else: ?>
                                    <p class="price item_price">$<?php echo e($product->price); ?></p>
                                <?php endif; ?>

                                <div class="description">
                                    <p><span>Descripción : </span> <?php echo e($product->description); ?></p>
                                </div>
                                <br><br>
                                <?php if($product->time_offer): ?>
                                    <div class="description">
                                        <h4>La oferta termina en:</h4>
                                        <ul style="font-size: 2em;">
                                            <li style="display: inline-block;"><span id="days"></span> Días</li>
                                            <li style="display: inline-block;"><span id="hours"></span> Hs</li>
                                            <li style="display: inline-block;"><span id="minutes"></span> Min</li>
                                            <li style="display: inline-block;"><span id="seconds"></span> Seg</li>
                                        </ul>
                                    </div>
                                <?php endif; ?>

                                <?php echo Form::open(['method' => 'POST','url' => ['/carrito/agregar', $product->id],'style'=>'display:inline']); ?>

                                <?php echo e(csrf_field()); ?>

                                <div class="color-quality">
                                    <h6>Cantidad :</h6>
                                    <div class="quantity">
                                        <div class="quantity-select">
                                            <input type="number" min="1" max="20" class="entry value1" name="quantity"
                                                   style="width: 15%;" placeholder="1" value="1">
                                        </div>
                                    </div>
                                </div>

                                <div class="color-quality">
                                    <div class="btn-group" data-toggle="buttons">
                                        <h6>Talle:</h6>
                                        <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <label class="btn btn-link">
                                                <label><?php echo e($size->size->size); ?></label>
                                                <input type="radio" name="size"
                                                       value="<?php echo e($size->size->size); ?>" required />
                                                <span class="glyphicon glyphicon-ok"></span>
                                            </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <br><br>
                                    <?php if($product->quantity == 0): ?>
                                        <a href="#" class="button1"> Sin Stock</a>
                                    <?php else: ?>
                                        <button type="submit" class="my-cart-b item_add">Agregar al
                                            carrito
                                        </button>
                                    <?php endif; ?>
                                </div>
                                <?php echo Form::close(); ?>

                                <br>

                                <h5>Envío estimado a todo el país $350</h5>
                                

                                <?php if($tarifa > 0): ?>
                                    <p class="well">El costo de envio es de aprox.: $ <?php echo e($tarifa); ?></p>
                                <?php elseif($tarifa == -1): ?>
                                    <p class="well">Error en el código postal <a
                                                href="https://www.andreani.com/buscador-de-codigos-postales"
                                                target="_blank">Consulte
                                            aquí</a></p>
                                <?php endif; ?>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                    <?php echo $__env->make('parts.product._aside', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="clearfix"></div>

                    <div class="product-w3agile">
                        <div class="product-grids">
                            <div class="col-md-8 product-grid1">
                                <div class="tab-wl3">
                                    <div class="bs-example bs-example-tabs" role="tabpanel"
                                         data-example-id="togglable-tabs">
                                        <ul id="myTab" class="nav nav-tabs left-tab" role="tablist">
                                            <li role="presentation" class="active"><a href="#home" id="home-tab"
                                                                                      role="tab"
                                                                                      data-toggle="tab"
                                                                                      aria-controls="home"
                                                                                      aria-expanded="true"><img
                                                            src="<?php echo e(asset('styleWeb/img/icons/circle.png')); ?>"> </a>
                                            </li>
                                            <li role="presentation"><a href="#reviews" role="tab" id="reviews-tab"
                                                                       data-toggle="tab" aria-controls="reviews">Reviews
                                                </a></li>

                                        </ul>
                                        <div id="myTabContent" class="tab-content">
                                            <div role="tabpanel" class="tab-pane fade in active" id="home"
                                                 aria-labelledby="home-tab">

                                            </div>
                                            <div role="tabpanel" class="tab-pane fade" id="reviews"
                                                 aria-labelledby="reviews-tab">
                                                <div class="descr">
                                                    <div class="reviews-top">
                                                        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="reviews-right">
                                                                <ul>
                                                                    <li><a href="#"><?php echo e($review->user->name); ?></a></li>
                                                                </ul>
                                                                <p><?php echo e($review->review); ?></p>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="clearfix"></div>
                                                    </div>
                                                    <?php if(Auth::check()): ?>
                                                        <?php echo Form::open(['method' => 'POST','route' => ['rating', $product->id],'style'=>'display:inline']); ?>

                                                        <?php echo e(csrf_field()); ?>

                                                        <?php if(!$userReview): ?>
                                                            <div class="reviews-bottom">
                                                                <h4>Agregar Reviews</h4>
                                                                <p>Tu email nunca será publicado. Solo publicaremos tu
                                                                    nombre de pila. *</p>
                                                                <p>Tu Rating sobre el producto</p>
                                                                <div class="acidjs-rating-stars">
                                                                    <input type="radio" name="rating" id="group-1-0"
                                                                           value="100" required/><label
                                                                            for="group-1-0"></label>
                                                                    <input type="radio" name="rating" id="group-1-1"
                                                                           value="80"/><label for="group-1-1"></label>
                                                                    <input type="radio" name="rating" id="group-1-2"
                                                                           value="60"/><label for="group-1-2"></label>
                                                                    <input type="radio" name="rating" id="group-1-3"
                                                                           value="40"/><label for="group-1-3"></label>
                                                                    <input type="radio" name="rating" id="group-1-4"
                                                                           value="20"/><label for="group-1-4"></label>
                                                                </div>
                                                                <br><br>
                                                                <textarea type="text" Name="review"
                                                                          placeholder="Mensaje..."
                                                                          required=""></textarea>
                                                                <input type="submit" value="Enviar">
                                                                <br>
                                                            </div>
                                                        <?php endif; ?>
                                                        <?php echo Form::Close(); ?>

                                                        <br><br>
                                                    <?php else: ?>
                                                        <div class="descr">
                                                            <div class="reviews-bottom">
                                                                <form method="POST" action="<?php echo e(route('login')); ?>">
                                                                    <?php echo csrf_field(); ?>
                                                                    <label>Debes ingresar para dejar tu
                                                                        review </label> <a href=""
                                                                                           class="btn btn-primary">Crear
                                                                        Cuenta</a>

                                                                    <div class="row">
                                                                        <div class="col-md-6 row-grid">
                                                                            <label>Email</label>
                                                                            <input type="email" value="Email"
                                                                                   class="<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                                                                                   Name="email"
                                                                                   onfocus="this.value = '';"
                                                                                   onblur="if (this.value == '') {this.value = 'Email';}"
                                                                                   required="">
                                                                        </div>
                                                                        <?php if($errors->has('email')): ?>
                                                                            <span class="invalid-feedback" role="alert">
                                                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                                                            </span>
                                                                        <?php endif; ?>

                                                                        <div class="col-md-6 row-grid">
                                                                            <label>Password</label>
                                                                            <input type="password" value="password"
                                                                                   class="<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"
                                                                                   Name="password"
                                                                                   onfocus="this.value = '';"
                                                                                   onblur="if (this.value == '') {this.value = 'Password';}"
                                                                                   required="">
                                                                            <?php if($errors->has('password')): ?>
                                                                                <span class="invalid-feedback"
                                                                                      role="alert">
                                                                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                                                                </span>
                                                                            <?php endif; ?>
                                                                        </div>
                                                                        <div class="clearfix"></div>
                                                                    </div>
                                                                    <input type="submit" value="Ingresar"> <a
                                                                            href="<?php echo e(route('password.request')); ?>">
                                                                        Olvide mi Password</a>
                                                                </form>
                                                            </div>
                                                        </div>
                                                        <br><br>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div role="tabpanel" class="tab-pane fade" id="custom"
                                                 aria-labelledby="custom-tab">

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="new-arrivals-w3agile">
                <div class="container">
                    <h3 class="tittle1">Productos Relacionados</h3>
                    <div class="arrivals-grids">
                        <?php $__currentLoopData = $relateds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3 arrival-grid simpleCart_shelfItem">
                                <div class="grid-arr">
                                    <div class="grid-arrival">
                                        <figure>
                                            <a href="<?php echo e(url('producto', $related->slug)); ?>">
                                                <div class="grid-img">
                                                    <img src="<?php echo e(asset('images/products/'.$related->photo)); ?>"
                                                         class="img-responsive" alt="<?php echo e($related->name); ?>">
                                                </div>
                                                <div class="grid-img">
                                                    <img src="<?php echo e(asset('images/products/'.$related->photo)); ?>"
                                                         class="img-responsive" alt="<?php echo e($related->name); ?>">
                                                </div>
                                            </a>
                                        </figure>
                                    </div>
                                    <div class="women">
                                        <h6><a href="<?php echo e(url('producto', $related->slug)); ?>"><?php echo e(str_limit($related->name, 20)); ?></a>
                                        </h6>

                                        <div class="block star-rating" style="margin-left: 38%;">
                                            <div class="back-stars small ghosting">
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                <i class="fa fa-star" aria-hidden="true"></i>

                                                <div class="front-stars" style="width: <?php echo e($related->rating); ?>%">
                                                    <i class="fa fa-star" aria-hidden="true"></i>
                                                    <i class="fa fa-star" aria-hidden="true"></i>
                                                    <i class="fa fa-star" aria-hidden="true"></i>
                                                    <i class="fa fa-star" aria-hidden="true"></i>
                                                    <i class="fa fa-star" aria-hidden="true"></i>
                                                </div>
                                            </div>
                                        </div>
                                        <br>
                                        <?php if($product->offer): ?>
                                            <h5>
                                                <del>$<?php echo e($product->price); ?></del>
                                            </h5>
                                            <h4 class="item_price">$<?php echo e($product->offer); ?></h4>
                                        <?php else: ?>
                                            <p><em class="item_price">$<?php echo e($product->price); ?></em></p>
                                        <?php endif; ?>
                                        <br>
                                        <a href="<?php echo e(url('producto', $product->slug)); ?>" class="my-cart-b item_add">Ver
                                            Más</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>