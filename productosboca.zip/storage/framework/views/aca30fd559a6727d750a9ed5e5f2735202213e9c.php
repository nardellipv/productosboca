<div class="latest-w3">
    <div class="container">
        
        <div class="latest-grids">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 latest-grid">
                <div class="latest-top">
                    <a href="<?php echo e(url('categoria', $category->slug)); ?>">
                    <img  src="<?php echo e(asset('images/categories/'.$category->photo)); ?>" class="img-responsive"  alt="<?php echo e($category->name); ?>">
                    </a>
                    <div class="latest-text">
                        <h4><?php echo e($category->name); ?></h4>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="clearfix"></div>
        </div>
    </div>
</div>