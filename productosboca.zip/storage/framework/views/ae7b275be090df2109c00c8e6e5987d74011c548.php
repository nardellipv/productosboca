<div class="col-md-3 product-agileinfo-grid">
    <div class="top-rates">
        <h3>Más vendidos</h3>
        <?php $__currentLoopData = $lastItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lastItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="recent-grids">
                <div class="recent-left">
                    <a href="<?php echo e(url('producto', $lastItem->slug)); ?>"><img class="img-responsive "
                                                                          src="<?php echo e(asset('images/products/'.$lastItem->photo)); ?>"
                                                                          alt="<?php echo e($lastItem->name); ?>"></a>
                </div>
                <div class="recent-right">
                    <h6 class="best2"><a href="<?php echo e(url('producto', $lastItem->slug)); ?>"><?php echo e($lastItem->name); ?></a></h6>
                    <?php if($lastItem->offer): ?>
                        <del>$<?php echo e($lastItem->price); ?></del>
                        <h4 class="item_price" style="display: inline;">$<?php echo e($lastItem->offer); ?></h4>
                    <?php else: ?>
                        <p><em class="item_price" style="display: inline;">$<?php echo e($lastItem->price); ?></em>
                    <?php endif; ?>
                    <div class="block star-rating" style="display: table-row;">
                        <div class="back-stars small ghosting">
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>

                            <div class="front-stars" style="width: <?php echo e($lastItem->rating); ?>%">
                                <i class="fa fa-star" aria-hidden="true"></i>
                                <i class="fa fa-star" aria-hidden="true"></i>
                                <i class="fa fa-star" aria-hidden="true"></i>
                                <i class="fa fa-star" aria-hidden="true"></i>
                                <i class="fa fa-star" aria-hidden="true"></i>
                            </div>
                        </div>
                    </div>
                    <br>
                </div>
                <div class="clearfix"></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
</div>