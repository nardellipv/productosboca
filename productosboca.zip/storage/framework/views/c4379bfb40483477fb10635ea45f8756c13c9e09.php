<div class="box">
    <div class="box-header">
        <h3 class="box-title">Listado de usuarios</h3>
    </div>
    <div class="box-body">
        <table id="example1" class="table table-bordered table-striped">
            <thead>
            <tr>
                <th>Nombre</th>
                <th>email</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $newsLetters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newsLetter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($newsLetter->name); ?></td>
                    <td><?php echo e($newsLetter->email); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>