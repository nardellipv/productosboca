<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('styleAdmin/plugins/datatables/dataTables.bootstrap.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="box">
    <div class="box-header">
        <h3 class="box-title">Listado de productos</h3>
        <a href="<?php echo e(route('products.create')); ?>" type="submit" class="btn btn-info pull-right">Crear producto</a>
    </div>
    <div class="box-body">
        <table id="example1" class="table table-bordered table-striped">
            <thead>
            <tr>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Precio</th>
                <th>Oferta</th>
                <th>Sección</th>
                <th>Categoría</th>
                <th>Ranting</th>
                <th>Acción</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e(str_limit($product->description,50)); ?></td>
                    <td>$<?php echo e($product->price); ?></td>
                    <td>$<?php echo e($product->offer); ?></td>
                    <td><?php echo e($product->section); ?></td>
                    <td><?php echo e($product->category->name); ?></td>
                    <td><?php echo e($product->rating); ?></td>
                    <td>
                        <div class="btn-group">
                            <div class="btn-group">
                                <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-warning"><i class="fa fa-pencil"></i></a>
                                <?php echo Form::open(['method' => 'DELETE','route' => ['products.destroy', $product->id],'style'=>'display:inline']); ?>

                                <?php echo e(Form::token()); ?>

                                <button type="submit" class="btn btn-warning"><i class="fa fa-trash"></i></button>
                                <?php echo Form::Close(); ?>

                            </div>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('styleAdmin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('styleAdmin/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
        $(function () {
            $("#example1").DataTable();
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>