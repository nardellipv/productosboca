<div class="content">
    <div class="ban-bottom-w3l">
        <div class="container">
            <div class="col-md-6 ban-bottom">
                <div class="ban-top">
                    <img src="images/p1.jpg" class="img-responsive" alt=""/>
                    <div class="ban-text">
                        <h4>Men’s Clothing</h4>
                    </div>
                    <div class="ban-text2 hvr-sweep-to-top">
                        <h4>50% <span>Off/-</span></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-6 ban-bottom3">
                <div class="ban-top">
                    <img src="images/p2.jpg" class="img-responsive" alt=""/>
                    <div class="ban-text1">
                        <h4>Women's Clothing</h4>
                    </div>
                </div>
                <div class="ban-img">
                    <div class=" ban-bottom1">
                        <div class="ban-top">
                            <img src="images/p3.jpg" class="img-responsive" alt=""/>
                            <div class="ban-text1">
                                <h4>T - Shirt</h4>
                            </div>
                        </div>
                    </div>
                    <div class="ban-bottom2">
                        <div class="ban-top">
                            <img src="images/p4.jpg" class="img-responsive" alt=""/>
                            <div class="ban-text1">
                                <h4>Hand Bag</h4>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>