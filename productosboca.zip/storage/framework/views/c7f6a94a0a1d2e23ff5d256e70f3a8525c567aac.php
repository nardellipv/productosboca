<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('styleAdmin/plugins/iCheck/all.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <?php echo $__env->make('layouts.alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('layouts.alerts.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="row">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <div class="col-md-6 col-sm-offset-2">
                        <?php echo Form::open(['method' => 'POST','route' => ['coupon.store']]); ?>

                        <?php echo e(csrf_field()); ?>

                        <div class="box-body">
                            <div class="form-group">
                                <label for="coupon">Cupón</label>
                                <input type="text" name="coupon" class="form-control" id="coupon"
                                       placeholder="Cupón">
                            </div>

                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="discount">Descuento</label>
                                        <input type="text" name="discount" class="form-control" id="discount"
                                               placeholder="Descuento">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>Estado</label>
                                        <select class="form-control" name="status">
                                            <option value="ACTIVE">Activo</option>
                                            <option value="DESACTIVE">Desactivo</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Agregar Cupón</button>
                        </div>
                        <?php echo Form::Close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('styleAdmin/plugins/datatables/dataTables.bootstrap.css')); ?>">
<?php $__env->stopSection(); ?>

<div class="box">
    <div class="box-header">
        <h3 class="box-title">Listado de compras</h3>
    </div>
    <div class="box-body">
        <table id="example1" class="table table-bordered table-striped">
            <thead>
            <tr>
                <th>Cupón</th>
                <th>Descuento</th>
                <th>Estado</th>
                <th>Acción</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $cuopons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuopon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($cuopon->coupon); ?></td>
                    <td><?php echo e($cuopon->discount); ?></td>
                    <td><?php echo e($cuopon->status); ?></td>
                    <td>
                        <div class="btn-group">
                            <div class="btn-group">
                                <?php echo Form::open(['method' => 'DELETE','route' => ['coupon.destroy', $cuopon->id],'style'=>'display:inline']); ?>

                                <?php echo e(Form::token()); ?>

                                <button type="submit" class="btn btn-warning"><i
                                            class="fa fa-trash"></i></button>
                                <?php echo Form::Close(); ?>

                                <?php if($cuopon->status == 'DESACTIVE'): ?>
                                    <a href="<?php echo e(route('cuopon.active', $cuopon->id)); ?>" class="btn btn-danger"><i class="fa fa-check"></i></a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('cuopon.desactive', $cuopon->id)); ?>" class="btn btn-primary"><i class="fa fa-remove"></i></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('styleAdmin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('styleAdmin/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
        $(function () {
            $("#example1").DataTable();
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>