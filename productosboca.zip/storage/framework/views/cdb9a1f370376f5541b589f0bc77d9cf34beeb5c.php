<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="login">
            <div class="main-agileits">
                <div class="form-w3agile">
                    <h3>Verificar tu email</h3>
                </div>
                <?php if(session('resent')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(__('Se ha enviado un nuevo enlace de verificación a su dirección de correo electrónico.')); ?>

                    </div>
                <?php endif; ?>
                <?php echo e(__('Antes de continuar por favor verifica tu email. Revisa también en la carpeta de spam.')); ?>

                <?php echo e(__('Si no te ha llegado el mail')); ?>, <a
                        href="<?php echo e(route('verification.resend')); ?>"><?php echo e(__('click aquí para enviar nuevamente el mail.')); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>