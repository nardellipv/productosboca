<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="products-agileinfo">
            <h2 class="tittle">Muchas gracias por registrarte</h2>
            <div class="container">
                <br><br>
                <p class="text-center">Ahora estaras acutalizado en cuando a las novedades que tenga el sitio y nuevos productos.</p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>