<?php $__env->startSection('content'); ?>
    <section class="content">
        <?php echo $__env->make('layouts.alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="row">
            <div class="col-md-6">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Listado Categorías</h3>
                    </div>
                    <div class="box-body">
                        <table class="table table-bordered">
                            <tr>
                                <th>Categoría</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($category->name); ?></td>
                                    <td><?php echo e($category->status); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <div class="btn-group">
                                                <a href="<?php echo e(route('categories.edit', $category->id)); ?>"
                                                   class="btn btn-warning"><i class="fa fa-pencil"></i></a>
                                                <?php echo Form::open(['method' => 'DELETE','route' => ['categories.destroy', $category->id],'style'=>'display:inline']); ?>

                                                <?php echo e(Form::token()); ?>

                                                <button type="submit" class="btn btn-warning"><i
                                                            class="fa fa-trash"></i></button>
                                                <?php echo Form::Close(); ?>

                                                <?php if($category->status == 'DESACTIVE'): ?>
                                                    <a href="<?php echo e(route('active', $category->id)); ?>" class="btn btn-danger"><i class="fa fa-check"></i></a>
                                                <?php else: ?>
                                                    <a href="<?php echo e(route('desactive', $category->id)); ?>" class="btn btn-primary"><i class="fa fa-remove"></i></a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
            <?php echo Form::open(['method' => 'POST','route' => ['categories.store'],'enctype' => 'multipart/form-data']); ?>

            <?php echo e(csrf_field()); ?>

            <div class="col-md-6">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="name">Nombre</label>
                        <input type="text" name="name" class="form-control" id="name"
                               placeholder="Nombre">
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <label>Status</label>
                        <select class="form-control" name="status">
                            <option value="ACTIVE">Activa</option>
                            <option value="DESACTIVE">Desactiva</option>
                        </select>
                    </div>
                </div>
                <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Agregar Categoría</button>
                </div>
            </div>
            <?php echo Form::Close(); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>